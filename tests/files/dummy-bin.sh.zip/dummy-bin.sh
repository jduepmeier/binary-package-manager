#!/usr/bin/env bash
## dummy script that will be installed in tests